// Product Data - Pointing to your local 'img' folder
const products = [
    { 
        name: "Red Chilli Powder", 
        frontImg: "./img/chilli-front img.jpg", 
        backImg: "./img/chilli-back img.jpg", 
        desc: "Finely ground premium chillies for vibrant color and authentic heat.",
        variants: [
            { weight: "50g", price: 50 },
            { weight: "100g", price: 80 },
            { weight: "250g", price: 180 },
            { weight: "500g", price: 300 },
            { weight: "1kg", price: 500 }
        ]
    },
    { 
        name: "Coriander Powder", 
        frontImg: "./img/coriander-front img.jpg", 
        backImg: "./img/coriander-back img.jpg", 
        desc: "Aromatic and fresh ground seeds for the perfect curry base.",
        variants: [
            { weight: "50g", price: 35 },
            { weight: "100g", price: 60 },
            { weight: "250g", price: 110 },
            { weight: "500g", price: 200 },
            { weight: "1kg", price: 350 }
        ]
    },
    { 
        name: "Garam Masala", 
        frontImg: "./img/garam masala-front img.jpg", 
        backImg: "./img/garam masala-back img.jpg", 
        desc: "Aromatic and fresh ground seeds for the perfect curry base.",
        variants: [
            { weight: "50g", price: 160 },
            { weight: "100g", price: 250 },
            { weight: "250g", price: 550 },
            { weight: "500g", price: 1000 },
            { weight: "1kg", price: 1900 }
        ]
    },
    { 
        name: "Turmeric Powder", 
        frontImg: "./img/turmeric-front img.jpg", 
        backImg: "./img/turmeric-back img.png", 
        desc: "100% Organic high-curcumin turmeric powder.",
        variants: [
            { weight: "50g", price: 50 },
            { weight: "100g", price: 80 },
            { weight: "250g", price: 180 },
            { weight: "500g", price: 300 },
            { weight: "1kg", price: 500 }
        ]
    }
];

const list = document.getElementById('product-list');

products.forEach((p, index) => {
    // Generate the dropdown options for weights
    let optionsHtml = p.variants.map(v => `<option value="${v.price}" data-weight="${v.weight}">${v.weight} - ₹${v.price}</option>`).join('');

    list.innerHTML += `
        <div class="card">
            <div class="image-container">
                <img src="${p.frontImg}" class="img-front" alt="${p.name} Front">
                <img src="${p.backImg}" class="img-back" alt="${p.name} Back">
                <div class="flip-hint">Hover to see back</div>
            </div>

            <div class="card-info">
                <h3>${p.name}</h3>
                <p class="product-desc">${p.desc}</p>
                
                <div class="pricing-box">
                    <label for="weight-${index}">Select Weight:</label>
                    <select id="weight-${index}" class="weight-select" onchange="updatePrice(${index})">
                        ${optionsHtml}
                    </select>
                </div>

                <div class="card-footer">
                    <span class="display-price" id="price-tag-${index}">₹${p.variants[0].price}</span>
                    <button onclick="orderViaWhatsApp(${index})" class="order-link">
                        <i class="fab fa-whatsapp"></i> Buy Now
                    </button>
                </div>
            </div>
        </div>
    `;
});

// Update price display when weight is changed
window.updatePrice = function(index) {
    const select = document.getElementById(`weight-${index}`);
    const priceTag = document.getElementById(`price-tag-${index}`);
    priceTag.innerText = `₹${select.value}`;
};

// Open WhatsApp with the specific product and weight
window.orderViaWhatsApp = function(index) {
    const p = products[index];
    const select = document.getElementById(`weight-${index}`);
    const selectedWeight = select.options[select.selectedIndex].getAttribute('data-weight');
    const selectedPrice = select.value;
    
    // --- ENTER THE CLIENT'S WHATSAPP NUMBER HERE ---
    // Format: Country Code + Phone Number (e.g., 919876543210). Do not include signs like '+' or '-'
    const whatsappNumber = "916387643090"; 
    
    const message = encodeURIComponent(`Hello Swaadica! I'd like to order ${p.name}.\nWeight: ${selectedWeight}\nPrice: ₹${selectedPrice}\nPlease confirm my order.`);
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
};

// 2. Navbar Scroll Effect Logic
window.addEventListener('scroll', function() {
    const nav = document.getElementById('main-nav');
    if (window.scrollY > 60) {
        nav.classList.add('scrolled');
    } else {
        nav.classList.remove('scrolled');
    }
});